This package relies on third-party software components governed by the license(s) indicated below:

Component Name: Protobuf-Net

License Type: "Apache"

[Protobuf-Net License](https://github.com/protobuf-net/protobuf-net/blob/main/Licence.txt)

Component Name: Protobuf

License Type: "BSD"

[Protobuf License](https://github.com/protocolbuffers/protobuf/blob/main/LICENSE)

Component Name: WebP.Net

License Type: "MIT"

[WebP.Net License](https://github.com/netpyoung/unity.webp/blob/master/LICENSE.md)
